# Rubber Duck Detection > 2023-05-09 1:21am
https://universe.roboflow.com/university-of-liverpool-od161/rubber-duck-detection-atuez

Provided by a Roboflow user
License: CC BY 4.0

